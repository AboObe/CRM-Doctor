@extends('doctor.base')
@section('action-content')

@endsection